package com.example.android.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val vinga = findViewById<ImageView>(R.id.ving)
        val inter = findViewById<ImageView>(R.id.inter)
        val open = findViewById<ImageView>(R.id.open)
        val dark = findViewById<ImageView>(R.id.dark)
        val yellow = findViewById<ImageView>(R.id.yellow)
        val inven = findViewById<ImageView>(R.id.inven)

        vinga.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.vinga)
                putExtra("titulo", "Vingadores")
                putExtra("tipo", "Filme")
                putExtra("enredo", "Após Thanos eliminar metade das criaturas vivas, os Vingadores têm de lidar com a perda de amigos e entes queridos. Com Tony Stark vagando perdido no espaço sem água e comida, Steve Rogers e Natasha Romanov lideram a resistência contra o titã louco.")
                putExtra("tituloorig", "Avengers")
                putExtra("Genero", "Ação, Ficção Cientifica e Fantasia")
                putExtra("ano", "2019")
                putExtra("Pais", "Estados Unidos da América")
                putExtra("direção", " Anthony Russo e Joe Russo")
                putExtra("elenco", "Robert Downey Jr, Chris Evans, Chris Hemsworth, Scarlett Johansson, Mark Ruffalo, Brie Larson, Paul Rudd, Jeremy Renner, Don Cheadle.")

            }
        startActivity(intent);
        }
        inter.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.inter)
                putExtra("titulo", "Interestelar")
                putExtra("tipo", "Filme")
                putExtra("enredo", "As reservas naturais da Terra estão chegando ao fim e um grupo de astronautas recebe a missão de verificar possíveis planetas para receberem a população mundial, possibilitando a continuação da espécie. Cooper é chamado para liderar o grupo e aceita a missão sabendo que pode nunca mais ver os filhos. Ao lado de Brand, Jenkins e Doyle, ele seguirá em busca de um novo lar.")
                putExtra("tituloorig", "interestellar")
                putExtra("Genero", "Drama, Fantasia & Ficção Científica, Espaço & Além")
                putExtra("ano", "2014")
                putExtra("Pais", "Canadá")
                putExtra("direção", " Christopher Nolan")
                putExtra("elenco", "Matthew McConaughey, Jessica Chastain, Anne Hathaway, Timothée Chalamet, Michael Caine.")

            }
            startActivity(intent);

        }
        open.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.oppen)
                putExtra("titulo", "Oppenheimer.")
                putExtra("tipo", "Filme")
                putExtra("enredo", "O físico J. Robert Oppenheimer trabalha com uma equipe de cientistas durante o Projeto Manhattan, levando ao desenvolvimento da bomba atômica.")
                putExtra("Genero", "Biografia, Drama, Guerra")
                putExtra("ano", "2023")
                putExtra("Pais", "Estados Unidos da América")
                putExtra("direção", " Christopher Nolan")
                putExtra("elenco", " Cillian Murphy, Emily Blunt, Matt Damon.")

            }
            startActivity(intent);

        }
        dark.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.dark)
                putExtra("titulo", "Dark.")
                putExtra("tipo", "Série")
                putExtra("enredo", "A rotina dos moradores vira de cabeça para baixo quando duas crianças desaparecem misteriosamente, nas proximidades de uma antiga usina nuclear. Segredos familiares começam a emergir à medida que a polícia investiga os sumiços e logo percebe uma relação com eventos também sombrios do passado.")
                putExtra("Genero", " Ficção científica e Mistério ")
                putExtra("ano", "2019")
                putExtra("Pais", "Alemanha")
                putExtra("direção", "Baran bo Odar")
                putExtra("elenco", "Louis Hofmann, Lisa Vicari, Gina Stiebitz, Oliver Masucci, Julika Jenkins, Moritz Jahn. ")

            }
            startActivity(intent);

        }
        yellow.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.yellowstone)
                putExtra("titulo", "Yellowstone.")
                putExtra("tipo", "Série")
                putExtra("enredo", "Na trama, acompanhamos os Duttons, uma família tradicional dos Estados Unidos proprietária da fazenda Yellowstone. Contudo, há um problema: todos desejam uma fatia da Yellowstone. A série nos envolve em uma batalha armada para impedir a gentrificação.")
                putExtra("tituloorig", "invencible")
                putExtra("Genero", "Faroeste, Drama e suspense ")
                putExtra("ano", "2018")
                putExtra("Pais", "Estados Unidos da América")
                putExtra("direção", "Taylor Sheridan")
                putExtra("elenco", "Kevin Costner, Kelly Reilly, Cole Hauser, Luke Grimes, Kelsey Chow, Wes Bentley, Jefferson White")

            }
            startActivity(intent);

        }
        inven.setOnClickListener{
            val intent = Intent(this, filmes::class.java).apply{
                putExtra("id_img", R.drawable.yellowstone)
                putExtra("titulo", "Invencivel.")
                putExtra("tipo", "Série")
                putExtra("enredo", "Inspirada no personagem Mark Grayson da revista em quadrinhos homônima criada por Robert Kirkman, 'Invencível' acompanha um adolescente absolutamente comum, que é filho do super-herói mais poderoso do planeta. Na juventude, ele começa a desenvolver poderes e descobre a dura realidade de ser um herói.")
                putExtra("Genero", "Animação, Fantasia cientifica, Ação")
                putExtra("ano", "2021")
                putExtra("Pais", "Estados Unidos da América")
                putExtra("direção", "James Mangold")

                            }
            startActivity(intent);

        }
    }
}