package com.example.android.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class filmes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filmes)

    }
}